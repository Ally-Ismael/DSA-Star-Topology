# Star-Topology
Star Topology in Java
